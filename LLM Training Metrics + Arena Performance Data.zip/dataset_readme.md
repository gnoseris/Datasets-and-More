# AI Models Dataset: Epoch AI + LMSYS Arena

## Overview
This dataset combines AI model training data from Epoch AI with performance benchmarks from the LMSYS Chatbot Arena leaderboard.

## Data Sources

### Epoch AI
- **notable_ai_models.csv**: Curated list of notable AI models with training metrics
- **all_ai_models.csv**: Comprehensive list of AI models with extended metadata

### LMSYS Arena
- **arena_hard_auto_leaderboard_v0.1.csv**: Arena Hard benchmark scores
- **leaderboard_table_*.csv**: 129 snapshots of the Chatbot Arena leaderboard (2023-06 to 2025-08)

## Dataset Statistics
- **Total models**: 2248
- **Columns**: 85
- **Models from Epoch AI (2023+)**: 2141
- **Models with Arena data**: 892
- **Models matched (both sources)**: 785
- **Models with MT-Bench scores**: 192
- **Models with Arena ELO ratings**: 172
- **Models with Arena Hard scores**: 141
- **Models with MMLU scores**: 303

## Key Columns

### Epoch AI Data
- `Model`: Model name
- `Organization`: Developing organization
- `Publication date`: Release date
- `Parameters`: Parameter count
- `Training compute (FLOP)`: Training compute in FLOPs
- `Training dataset size (total)`: Training data size
- `Frontier model`: Whether the model is classified as frontier
- `Open model weights?`: Whether model weights are publicly available

### Arena Data
- `arena_hard_score`: Arena Hard benchmark score (0-100)
- `mt_bench_score`: MT-Bench score (0-10)
- `mmlu_score`: MMLU benchmark score (0-1)
- `arena_elo_rating`: Arena Elo rating
- `arena_license`: Model license
- `arena_organization`: Organization from Arena data
- `arena_link`: Link to model page

### Derived Columns
- `data_source`: Origin of the model (epoch_only, arena_only, both)
- `model_normalized`: Normalized model name used for matching
- `match_score`: Fuzzy match confidence score (0-1)
- `model_age_days`: Approximate age in days
- `is_frontier_model`: Whether the model is a frontier model

## Model Matching Methodology
Model names were matched using:
1. **Normalization**: Lowercase, remove version dates, remove special characters
2. **Fuzzy matching**: Jaccard similarity + sequence similarity
3. **Threshold**: 0.6 minimum match score

## License
CC0 - Public Domain

## Citation
If you use this dataset in your research, please cite:
- Epoch AI: https://epoch.ai
- LMSYS Chatbot Arena: https://chat.lmsys.org
